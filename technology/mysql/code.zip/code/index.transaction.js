const pool = require("./pool");

//

function main() {
  pool.getConnection(function (err, conn) {
    //   开启事务
    conn.beginTransaction(function (callback) {
      conn.query(
        "update `student` set `Sex`= ? where `StudentNo`=?",
        [0, 1000],
        function (err, results) {
          if (err) {
            console.log(err);
            console.log("rollback");
            // 回滚
            return conn.rollback();
          }
          console.log(results);

          //   提交
          conn.commit(function (err) {
            if (err) {
              return conn.rollback();
            }
          });

          // 释放连接
          conn.release();
          pool.releaseConnection(conn);
          pool.end();
        }
      );
    });
  });
}

main();
