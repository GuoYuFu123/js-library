const pool = require("./pool");

function main(name) {
  // 直接查询
  // "SELECT * FROM `student` WHERE `StudentName` = '张强' or 1=1 or ''='' "
  const sql = "SELECT * FROM `student` WHERE `StudentName` = '" + name + "'";
  pool.query(sql, function (err, results, fields) {
    console.log(results);  // 所有的数据
    pool.end();
  });

  // 预编译语句 Prepared Statements
  pool.getConnection(function (err, conn) {
    conn.query(
      "SELECT * FROM `student` WHERE `StudentName` = ?",
      [name],
      function (err, results) {
        console.log(results); // []
      }
    );
    // Don't forget to release the connection when finished!
    pool.releaseConnection(conn);
  });
}

main("张强' or 1 =1 or '' ='");
