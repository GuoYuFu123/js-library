const mysql = require("mysql2");

function main() {
  // create the connection to database
  const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    port: 3306,
    password: "******",
    database: "test",
  });

  // simple query
  connection.query("SELECT * FROM `student`", function (err, results, fields) {
    console.log(results); // results contains rows returned by server
    // console.log(fields); // fields contains extra meta data about results, if available
  });

  // with placeholder
  connection.query(
    "SELECT * FROM `student` WHERE `StudentName` = ? AND `Sex` = ?",
    ["刘强", 0],
    function (err, results) {
      console.log(results);
    }
  );
  //   使用完毕要释放连接，不然会一直占用
  connection.end();
}

main();
