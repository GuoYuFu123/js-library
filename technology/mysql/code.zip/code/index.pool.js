const pool = require("./pool");

function main() {
  // 直接查询
  pool.query("SELECT * FROM `student`", function (err, results, fields) {
    console.log(results);
    pool.end();
  });

 
  pool.getConnection(function (err, conn) {
    conn.query(
      "SELECT * FROM `student` WHERE `StudentName` = ? AND `Sex` = ?",
      ["刘强", 0],
      function (err, results) {
        console.log(results);
      }
    );
    // Don't forget to release the connection when finished!
    pool.releaseConnection(conn);
  });
}

main();
